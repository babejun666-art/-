/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Order, OrderStatus } from '../types';
import { Clock, Gift, User, Heart, Compass, CheckCircle2, MapPin, Phone, MessageSquare, AlertTriangle, Calendar, Award, BookOpen, Activity, Play } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface OrderTrackerProps {
  orders: Order[];
  onAdvanceOrderStatus: (orderId: string) => void;
  onCancelOrder: (orderId: string) => void;
}

export default function OrderTracker({
  orders,
  onAdvanceOrderStatus,
  onCancelOrder
}: OrderTrackerProps) {
  const [activeTab, setActiveTab] = useState<'all' | 'active' | 'completed'>('all');
  const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);
  const [callingContact, setCallingContact] = useState<{ name: string; phone: string } | null>(null);
  const [callDuration, setCallDuration] = useState(0);

  React.useEffect(() => {
    let timer: any;
    if (callingContact) {
      setCallDuration(0);
      timer = setInterval(() => {
        setCallDuration((prev) => prev + 1);
      }, 1000);
    } else {
      setCallDuration(0);
    }
    return () => clearInterval(timer);
  }, [callingContact]);

  const formatDuration = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const secs = sec % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const filteredOrders = orders.filter((o) => {
    if (activeTab === 'all') return true;
    if (activeTab === 'active') return o.status !== 'completed' && o.status !== 'cancelled';
    if (activeTab === 'completed') return o.status === 'completed';
    return true;
  });

  const getStatusBadge = (status: OrderStatus) => {
    switch (status) {
      case 'pending':
        return <span className="text-xs bg-slate-100 text-slate-600 px-2.5 py-1 rounded-full font-medium">匹配中</span>;
      case 'matched':
        return <span className="text-xs bg-blue-50 text-blue-600 border border-blue-100 px-2.5 py-1 rounded-full font-medium">陪护师已接单</span>;
      case 'ongoing':
        return <span className="text-xs bg-amber-50 text-amber-600 border border-amber-200 px-2.5 py-1 rounded-full font-medium flex items-center gap-1 animate-pulse">● 陪伴进行中</span>;
      case 'completed':
        return <span className="text-xs bg-emerald-50 text-emerald-600 border border-emerald-100 px-2.5 py-1 rounded-full font-medium">服务已圆满完成</span>;
      case 'cancelled':
        return <span className="text-xs bg-slate-100 text-slate-400 px-2.5 py-1 rounded-full font-medium">已取消</span>;
      default:
        return null;
    }
  };

  const selectedOrder = orders.find((o) => o.id === selectedOrderId) || filteredOrders[0] || null;

  return (
    <div id="order-tracker" className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      {/* Left side: Order List */}
      <div className="lg:col-span-5 bg-white rounded-2xl shadow-sm border border-orange-100 p-5 flex flex-col h-[650px]">
        <div className="mb-4">
          <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
            <Clock className="w-5 h-5 text-orange-500" />
            孝心订单与进度跟踪
          </h2>
          <p className="text-xs text-slate-500 mt-1">实时掌握陪护师上门动态，查收温情反馈报告</p>
        </div>

        {/* Tab Controls */}
        <div className="flex bg-slate-100 rounded-xl p-1 mb-4">
          {(['all', 'active', 'completed'] as const).map((tab) => (
            <button
              key={tab}
              id={`order-tab-${tab}`}
              onClick={() => setActiveTab(tab)}
              className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                activeTab === tab ? 'bg-white text-orange-600 shadow-xs' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              {tab === 'all' ? '全部订单' : tab === 'active' ? '进行中' : '已完成'}
            </button>
          ))}
        </div>

        {/* Order Scroll area */}
        <div className="flex-1 overflow-y-auto space-y-3 pr-1 scrollbar-thin">
          {filteredOrders.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-slate-400 text-center py-20">
              <Compass className="w-10 h-10 mb-2 stroke-1" />
              <p className="text-sm">没有找到相关订单</p>
              <p className="text-xs text-slate-300 mt-1">您可以通过右侧服务表单发起您的第一笔关爱预约</p>
            </div>
          ) : (
            filteredOrders.map((order) => {
              const isSelected = selectedOrder?.id === order.id;
              return (
                <div
                  key={order.id}
                  id={`order-card-summary-${order.id}`}
                  onClick={() => setSelectedOrderId(order.id)}
                  className={`cursor-pointer rounded-xl p-4 border transition-all text-left ${
                    isSelected
                      ? 'border-orange-500 bg-orange-50/20 shadow-xs'
                      : 'border-slate-100 bg-slate-50/30 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <span className="text-[10px] text-slate-400 font-mono">订单号: {order.id.split('_')[1]}</span>
                    {getStatusBadge(order.status)}
                  </div>

                  <h3 className="text-sm font-bold text-slate-800 mt-2 line-clamp-1">{order.service.title}</h3>

                  <div className="mt-3 flex items-center justify-between text-xs text-slate-600">
                    <div className="flex items-center gap-1.5 font-medium">
                      <User className="w-3.5 h-3.5 text-slate-400" />
                      <span>{order.elder.name} ({order.elder.relation})</span>
                    </div>
                    <span className="text-slate-400">{order.scheduledTime.split(' ')[0]}</span>
                  </div>

                  <div className="mt-2.5 pt-2.5 border-t border-slate-100 flex items-center justify-between">
                    <span className="text-[10px] text-slate-500 flex items-center gap-1">
                      {order.gift ? (
                        <><Gift className="w-3 h-3 text-orange-500" /> 随赠：{order.gift.name.substring(0, 10)}...</>
                      ) : (
                        '仅纯陪伴服务'
                      )}
                    </span>
                    <span className="text-xs font-extrabold text-orange-600">
                      ¥{order.totalPrice}
                    </span>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Right side: Selected Order Detail View */}
      <div className="lg:col-span-7 bg-white rounded-2xl shadow-sm border border-orange-100 p-6 flex flex-col h-[650px] overflow-y-auto">
        <AnimatePresence mode="wait">
          {selectedOrder ? (
            <motion.div
              key={selectedOrder.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.15 }}
              className="space-y-6"
            >
              {/* Header block */}
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 border-b border-slate-100 pb-4">
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="text-base font-bold text-slate-800">{selectedOrder.service.title}</h3>
                    {getStatusBadge(selectedOrder.status)}
                  </div>
                  <p className="text-xs text-slate-400 mt-1">预约时间：{selectedOrder.scheduledTime} · 时长：{selectedOrder.durationHours}小时</p>
                </div>

                {/* Simulation Control (推进服务状态) */}
                {selectedOrder.status !== 'completed' && selectedOrder.status !== 'cancelled' && (
                  <div className="flex items-center gap-2 self-start sm:self-center shrink-0">
                    <button
                      id="btn-advance-order"
                      onClick={() => onAdvanceOrderStatus(selectedOrder.id)}
                      className="flex items-center gap-1.5 px-3.5 py-1.5 bg-orange-500 hover:bg-orange-600 text-white text-xs font-bold rounded-xl shadow-xs transition-all animate-bounce hover:animate-none"
                    >
                      <Play className="w-3 h-3 fill-current" /> 推进服务进度(演示)
                    </button>
                    <button
                      id="btn-cancel-order"
                      onClick={() => {
                        if (confirm('确定要取消该孝心预约吗？')) {
                          onCancelOrder(selectedOrder.id);
                        }
                      }}
                      className="px-2.5 py-1.5 border border-slate-200 text-slate-500 hover:text-red-500 hover:bg-red-50 text-xs font-medium rounded-xl transition-all"
                    >
                      取消订单
                    </button>
                  </div>
                )}
              </div>

              {/* Grid content */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                {/* 1. Elder & Gift Block */}
                <div className="space-y-4">
                  <div className="bg-slate-50/60 rounded-2xl p-4 border border-slate-100">
                    <h4 className="text-xs font-bold text-slate-700 mb-2.5 flex items-center gap-1.5">
                      <Heart className="w-4 h-4 text-orange-500 fill-orange-500/10" />
                      长辈档案与身体近况
                    </h4>
                    <p className="text-sm font-bold text-slate-800">{selectedOrder.elder.name} ({selectedOrder.elder.relation})</p>
                    <p className="text-xs text-slate-500 mt-1">{selectedOrder.elder.gender === 'male' ? '男' : '女'} · {selectedOrder.elder.age}岁 · {selectedOrder.elder.phone}</p>
                    <div className="mt-2.5 flex items-start gap-1 text-xs text-slate-600">
                      <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                      <span>{selectedOrder.elder.address}</span>
                    </div>

                    {selectedOrder.elder.healthNotice && (
                      <div className="mt-3 bg-red-50 border border-red-100 rounded-xl p-2 flex items-start gap-1.5">
                        <AlertTriangle className="w-3.5 h-3.5 text-red-500 shrink-0 mt-0.5" />
                        <p className="text-[10px] text-red-700 leading-relaxed">{selectedOrder.elder.healthNotice}</p>
                      </div>
                    )}
                  </div>

                  {/* 紧急安全联系通道一键拨打 */}
                  {(selectedOrder.status === 'ongoing' || selectedOrder.status === 'completed') && (
                    selectedOrder.elder.emergencyContactName ? (
                      <div className="bg-red-50/50 border border-red-200/60 rounded-2xl p-4 text-slate-800 space-y-3 shadow-xs">
                        <div className="flex items-center gap-2 text-red-800">
                          <AlertTriangle className="w-4 h-4 text-red-600" />
                          <h4 className="text-xs font-bold">安全预警 · 紧急联系人通道</h4>
                        </div>
                        <div className="text-xs space-y-1 bg-white/70 p-2.5 rounded-xl border border-red-100/50">
                          <p className="flex items-center justify-between">
                            <span className="text-slate-500">紧急联系人:</span>
                            <span className="font-semibold text-slate-800">{selectedOrder.elder.emergencyContactName}</span>
                          </p>
                          <p className="flex items-center justify-between mt-1 pt-1 border-t border-slate-100">
                            <span className="text-slate-500">联系电话:</span>
                            <span className="font-mono font-bold text-slate-800">{selectedOrder.elder.emergencyContactPhone || '未填写'}</span>
                          </p>
                        </div>
                        {selectedOrder.elder.emergencyContactPhone && (
                          <button
                            id="btn-dial-emergency-contact"
                            onClick={() => setCallingContact({
                              name: selectedOrder.elder.emergencyContactName!,
                              phone: selectedOrder.elder.emergencyContactPhone!
                            })}
                            className="w-full flex items-center justify-center gap-1.5 py-2.5 px-3 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-xl transition-all shadow-sm shadow-red-600/10"
                          >
                            <Phone className="w-3.5 h-3.5 animate-bounce" />
                            一键呼叫紧急联系人
                          </button>
                        )}
                      </div>
                    ) : (
                      <div className="bg-slate-50 border border-slate-200 border-dashed rounded-2xl p-4 text-slate-500 space-y-2">
                        <div className="flex items-center gap-2 text-slate-700">
                          <AlertTriangle className="w-4 h-4 text-slate-400" />
                          <h4 className="text-xs font-bold">未配置紧急联系人</h4>
                        </div>
                        <p className="text-[11px] leading-relaxed">
                          当前陪伴服务进行中，为了长辈安全，建议点击「长辈个人档案」去完善紧急联系人信息。
                        </p>
                      </div>
                    )
                  )}

                  {/* Gift Info */}
                  {selectedOrder.gift && (
                    <div className="bg-orange-50/30 rounded-2xl p-4 border border-orange-100/60 flex items-start gap-3">
                      <div className="w-10 h-10 rounded-xl bg-orange-100 text-orange-600 flex items-center justify-center shrink-0">
                        <Gift className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="text-xs font-bold text-orange-950 flex items-center gap-1">
                          随赠慰问礼
                        </h4>
                        <p className="text-xs font-semibold text-slate-800 mt-0.5">{selectedOrder.gift.name}</p>
                        <p className="text-[10px] text-slate-500 mt-0.5">{selectedOrder.gift.description}</p>
                      </div>
                    </div>
                  )}
                </div>

                {/* 2. Matched Companion Block */}
                <div className="bg-slate-50/60 rounded-2xl p-4 border border-slate-100 space-y-3">
                  <h4 className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                    <Award className="w-4 h-4 text-orange-500" />
                    专属金牌陪护师
                  </h4>
                  {selectedOrder.companion ? (
                    <div className="space-y-3">
                      <div className="flex items-center gap-3">
                        <span className="text-2xl bg-white w-10 h-10 rounded-full border border-slate-100 flex items-center justify-center shrink-0 shadow-xs">
                          {selectedOrder.companion.avatar}
                        </span>
                        <div>
                          <p className="text-sm font-bold text-slate-800">{selectedOrder.companion.name}</p>
                          <p className="text-xs text-slate-500">经验：{selectedOrder.companion.experienceYears}年 · 评分：⭐{selectedOrder.companion.rating.toFixed(1)}</p>
                        </div>
                      </div>
                      <p className="text-xs text-slate-600 leading-relaxed italic bg-white p-2.5 rounded-xl border border-slate-100">
                        "{selectedOrder.companion.bio}"
                      </p>
                      <div className="flex flex-wrap gap-1">
                        {selectedOrder.companion.tags.map((tag, idx) => (
                          <span key={idx} className="text-[10px] bg-slate-200/60 text-slate-600 px-1.5 py-0.5 rounded-md">
                            {tag}
                          </span>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <p className="text-xs text-slate-400 py-6 text-center">系统正在智能匹配最合适的陪伴师...</p>
                  )}
                </div>
              </div>

              {/* 3. Personalized Preference configured by user */}
              <div className="bg-orange-50/20 border border-orange-100/60 rounded-2xl p-4 space-y-3">
                <h4 className="text-xs font-bold text-orange-900 flex items-center gap-1.5">
                  <MessageSquare className="w-4 h-4 text-orange-600" />
                  定制服务偏好设置
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5 text-xs text-slate-700">
                  <div className="space-y-1">
                    <p className="font-semibold text-slate-500">期望陪护性格风格：</p>
                    <p className="text-slate-800 font-medium">{selectedOrder.preference.companionPersonality}</p>
                  </div>
                  <div className="space-y-1">
                    <p className="font-semibold text-slate-500">重点关注寒暄话题：</p>
                    <div className="flex flex-wrap gap-1 mt-0.5">
                      {selectedOrder.preference.chatTopics.map((t, idx) => (
                        <span key={idx} className="bg-orange-100/60 text-orange-800 text-[10px] px-1.5 py-0.5 rounded">
                          {t}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div className="space-y-1 md:col-span-2">
                    <p className="font-semibold text-slate-500">忌讳/避讳话题：</p>
                    <p className="text-slate-800 bg-white/50 border border-slate-100 px-2 py-1 rounded-lg">
                      {selectedOrder.preference.tabooTopics}
                    </p>
                  </div>
                  <div className="space-y-1 md:col-span-2">
                    <p className="font-semibold text-slate-500">长辈习惯或特殊嘱咐：</p>
                    <p className="text-slate-800 bg-white/50 border border-slate-100 px-2 py-1 rounded-lg">
                      {selectedOrder.preference.specialInstructions}
                    </p>
                  </div>
                </div>
              </div>

              {/* 4. Live Timeline Stepper */}
              <div className="border-t border-slate-100 pt-5">
                <h4 className="text-xs font-bold text-slate-700 mb-4 flex items-center gap-1.5">
                  <Activity className="w-4 h-4 text-orange-500" />
                  上门服务实时进程
                </h4>
                <div className="space-y-5">
                  {selectedOrder.timeline.map((step, idx) => (
                    <div key={idx} className="relative flex gap-4 text-left">
                      {idx < selectedOrder.timeline.length - 1 && (
                        <div className={`absolute left-3.5 top-7 bottom-[-20px] w-[2px] ${
                          step.status === 'done' ? 'bg-orange-500' : 'bg-slate-200'
                        }`} />
                      )}

                      <div className={`w-7.5 h-7.5 rounded-full flex items-center justify-center shrink-0 z-10 ${
                        step.status === 'done'
                          ? 'bg-orange-500 text-white shadow-sm shadow-orange-500/10'
                          : step.status === 'current'
                          ? 'bg-amber-500 text-white ring-4 ring-amber-100 animate-pulse'
                          : 'bg-slate-100 text-slate-400'
                      }`}>
                        {step.status === 'done' ? (
                          <CheckCircle2 className="w-4 h-4 stroke-[3]" />
                        ) : (
                          <span className="text-xs font-bold">{idx + 1}</span>
                        )}
                      </div>

                      <div className="flex-1 pt-0.5">
                        <div className="flex items-baseline justify-between gap-2">
                          <h5 className={`text-xs font-bold ${
                            step.status === 'current' ? 'text-amber-600' : step.status === 'done' ? 'text-slate-800' : 'text-slate-400'
                          }`}>
                            {step.title}
                          </h5>
                          <span className="text-[10px] text-slate-400 font-mono shrink-0">{step.time}</span>
                        </div>
                        <p className={`text-xs mt-1 leading-relaxed ${
                          step.status === 'upcoming' ? 'text-slate-300' : 'text-slate-500'
                        }`}>
                          {step.description}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* 5. Heartwarming Visit Report (探望反馈报告) */}
              {selectedOrder.status === 'completed' && selectedOrder.visitReport && (
                <div className="border-t border-slate-100 pt-5 space-y-4 animate-fadeIn">
                  <div className="bg-emerald-50/40 border border-emerald-100 rounded-3xl p-5 space-y-4">
                    <div className="flex items-center justify-between border-b border-emerald-100/50 pb-3">
                      <div>
                        <h4 className="text-sm font-extrabold text-emerald-950 flex items-center gap-1.5">
                          <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                          暖心探望服务报告
                        </h4>
                        <p className="text-[10px] text-emerald-700/80 mt-0.5">本次服务已安全、温馨地送达，以下为现场反馈</p>
                      </div>
                      <span className="text-xs bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full font-bold">
                        长辈今日情况: {selectedOrder.visitReport.elderStatus}
                      </span>
                    </div>

                    {/* Activity log */}
                    <div className="space-y-2 text-xs">
                      <p className="font-bold text-emerald-950 flex items-center gap-1">
                        <BookOpen className="w-4 h-4 text-emerald-600" />
                        陪伴活动日志：
                      </p>
                      <ul className="space-y-1.5 pl-5 list-disc text-slate-700 leading-relaxed">
                        {selectedOrder.visitReport.activityLog.map((log, i) => (
                          <li key={i}>{log}</li>
                        ))}
                      </ul>
                    </div>

                    {/* Companion private notes */}
                    <div className="bg-white rounded-2xl p-4 border border-emerald-100/60 space-y-2">
                      <p className="text-xs font-bold text-emerald-950 flex items-center gap-1">
                        <Award className="w-4 h-4 text-emerald-600" />
                        陪护师暖心寄语：
                      </p>
                      <p className="text-xs text-slate-600 leading-relaxed whitespace-pre-line">
                        {selectedOrder.visitReport.companionNotes}
                      </p>
                    </div>

                    <div className="text-[10px] text-emerald-600 flex items-center gap-1 justify-center bg-emerald-100/30 py-2 rounded-xl">
                      <span>✓ 长辈照片已上传，您可通过移动端App查看长辈喜笑颜开的合影。</span>
                    </div>
                  </div>
                </div>
              )}
            </motion.div>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-slate-400 py-32">
              <Clock className="w-12 h-12 mb-3 stroke-1 text-slate-300" />
              <p className="text-sm">请选择左侧列表中的订单查看详情</p>
            </div>
          )}
        </AnimatePresence>
      </div>

      {/* Call Simulator Overlay */}
      {callingContact && (
        <div className="fixed inset-0 bg-slate-900/95 z-[9999] flex flex-col items-center justify-center text-white backdrop-blur-md">
          <div className="w-full max-w-sm text-center px-6 space-y-8">
            <div className="space-y-4">
              <div className="relative w-24 h-24 mx-auto flex items-center justify-center bg-red-600 rounded-full animate-pulse shadow-lg shadow-red-600/30">
                <Phone className="w-10 h-10 text-white animate-bounce" />
                <div className="absolute inset-0 rounded-full border-4 border-red-500 animate-ping opacity-30" />
              </div>
              <p className="text-xs font-bold text-red-500 tracking-widest uppercase">紧急专线通话呼叫中</p>
            </div>

            <div className="space-y-2">
              <h3 className="text-2xl font-extrabold tracking-tight">{callingContact.name}</h3>
              <p className="text-sm font-mono text-slate-400">{callingContact.phone}</p>
            </div>

            <div className="space-y-1 bg-slate-800/50 border border-slate-700/50 rounded-2xl p-4">
              <p className="text-xs text-slate-400">正在接通安全专线...</p>
              <p className="text-2xl font-mono font-bold text-emerald-400 mt-1">{formatDuration(callDuration)}</p>
              <div className="flex justify-center items-end gap-1 h-6 mt-2">
                <span className="w-1 bg-emerald-500 rounded-full animate-bounce" style={{ height: '30%', animationDelay: '0s' }} />
                <span className="w-1 bg-emerald-500 rounded-full animate-bounce" style={{ height: '70%', animationDelay: '0.1s' }} />
                <span className="w-1 bg-emerald-500 rounded-full animate-bounce" style={{ height: '50%', animationDelay: '0.2s' }} />
                <span className="w-1 bg-emerald-500 rounded-full animate-bounce" style={{ height: '90%', animationDelay: '0.3s' }} />
                <span className="w-1 bg-emerald-500 rounded-full animate-bounce" style={{ height: '40%', animationDelay: '0.4s' }} />
              </div>
            </div>

            <p className="text-xs text-slate-500 px-4 leading-relaxed">
              提示：此呼叫为紧急电话模拟拨打，正式版本将联动家庭安全专线，同时向当前上门陪护师发送强制手机震动警报与坐标定位。
            </p>

            <button
              id="btn-hang-up"
              onClick={() => setCallingContact(null)}
              className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-6 rounded-2xl transition-all shadow-lg shadow-red-600/20 text-sm flex items-center justify-center gap-2 cursor-pointer"
            >
              <Phone className="w-4 h-4 rotate-[135deg]" /> 挂断紧急电话
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

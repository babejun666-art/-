/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Elder, ServiceItem, ComfortGift, BookingPreference, Order, Companion } from '../types';
import { SERVICES, COMFORT_GIFTS, COMPANIONS } from '../data';
import { Clock, Gift, User, Heart, ShieldCheck, AlertCircle, Calendar, Sparkles, ChevronRight, MessageCircleOff, HelpCircle } from 'lucide-react';
import { motion } from 'motion/react';

interface BookingFormProps {
  elders: Elder[];
  selectedElderId: string | null;
  onBookingSuccess: (order: Order) => void;
  initialServiceId?: string;
}

const ALL_TOPICS = ['当年旧事', '养生保健', '户外风景', '国家大事', '花草盆栽', '越剧艺术', '智能手机使用'];

export default function BookingForm({
  elders,
  selectedElderId,
  onBookingSuccess,
  initialServiceId = 'greeting'
}: BookingFormProps) {
  const [selectedElder, setSelectedElder] = useState<Elder | null>(null);
  const [selectedService, setSelectedService] = useState<ServiceItem>(SERVICES[0]);
  const [selectedGift, setSelectedGift] = useState<ComfortGift>(COMFORT_GIFTS[1]); // Default to traditional pastry
  const [duration, setDuration] = useState<number>(0.5); // Default to half an hour
  const [scheduledDate, setScheduledDate] = useState<string>('today'); // 'today' | 'tomorrow' | 'custom'
  const [customDate, setCustomDate] = useState<string>('');
  const [scheduledTimeSlot, setScheduledTimeSlot] = useState<string>('10:00 - 11:30');
  
  // Preferences
  const [companionPersonality, setCompanionPersonality] = useState<string>('温柔细致');
  const [selectedTopics, setSelectedTopics] = useState<string[]>(['当年旧事', '养生保健']);
  const [tabooTopics, setTabooTopics] = useState<string>('');
  const [specialInstructions, setSpecialInstructions] = useState<string>('');

  // Sync selected elder
  useEffect(() => {
    if (selectedElderId) {
      const elder = elders.find(e => e.id === selectedElderId);
      if (elder) setSelectedElder(elder);
    } else if (elders.length > 0) {
      setSelectedElder(elders[0]);
    } else {
      setSelectedElder(null);
    }
  }, [selectedElderId, elders]);

  // Adjust service item if initialServiceId changes
  useEffect(() => {
    const service = SERVICES.find(s => s.id === initialServiceId);
    if (service) {
      setSelectedService(service);
      setDuration(service.minDuration);
    }
  }, [initialServiceId]);

  const handleServiceChange = (serviceId: string) => {
    const service = SERVICES.find(s => s.id === serviceId);
    if (service) {
      setSelectedService(service);
      setDuration(service.minDuration);
    }
  };

  const toggleTopic = (topic: string) => {
    if (selectedTopics.includes(topic)) {
      setSelectedTopics(selectedTopics.filter(t => t !== topic));
    } else {
      setSelectedTopics([...selectedTopics, topic]);
    }
  };

  const calculateTotal = () => {
    const serviceCharge = selectedService.pricePerHour * duration;
    const giftCharge = selectedGift.price;
    return Math.round(serviceCharge + giftCharge);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedElder) {
      alert('请先选择或新增一位长辈档案！');
      return;
    }

    // Match companion based on elder hobbies/personality
    let matchedCompanion: Companion = COMPANIONS[0]; // default
    if (selectedService.id === 'care') {
      matchedCompanion = COMPANIONS[1]; // 李强 (strong, efficient at hospital)
    } else if (selectedService.id === 'reading') {
      matchedCompanion = COMPANIONS[3]; // 陈然 (young student reader)
    } else if (selectedElder.personality.includes('安静') || selectedElder.personality.includes('温和')) {
      matchedCompanion = COMPANIONS[2]; // 王淑芬 (patient, retired social worker)
    } else if (selectedTopics.includes('当年旧事') || selectedElder.hobbies.includes('下象棋')) {
      matchedCompanion = COMPANIONS[0]; // 张阿姨
    }

    const dateStr = scheduledDate === 'today' ? '今天' : scheduledDate === 'tomorrow' ? '明天' : customDate;
    const timeDisplay = `${dateStr} ${scheduledTimeSlot}`;

    const preference: BookingPreference = {
      companionPersonality,
      chatTopics: selectedTopics,
      tabooTopics: tabooTopics || '无特别避讳话题',
      specialInstructions: specialInstructions || '无特别说明'
    };

    const newOrder: Order = {
      id: 'order_' + Date.now(),
      elder: selectedElder,
      service: selectedService,
      gift: selectedGift.id === 'gift_none' ? undefined : selectedGift,
      durationHours: duration,
      scheduledTime: timeDisplay,
      totalPrice: calculateTotal(),
      preference,
      status: 'matched',
      companion: matchedCompanion,
      createdAt: new Date().toISOString(),
      timeline: [
        { title: '订单已提交', time: '刚才', description: `您为${selectedElder.name}成功预订了【${selectedService.title}】服务。`, status: 'done' },
        { title: '已成功匹配陪护师', time: '刚才', description: `已为您匹配最契合的陪护师【${matchedCompanion.name}】，TA正在认真阅读您的偏好设置。`, status: 'current' },
        { title: '上门服务', time: dateStr, description: `陪护师将携带精选礼物，准时在 ${scheduledTimeSlot} 抵达进行陪伴服务。`, status: 'upcoming' }
      ]
    };

    onBookingSuccess(newOrder);
  };

  return (
    <form id="booking-form" onSubmit={handleSubmit} className="space-y-6">
      {/* 1. Select Elder */}
      <div className="bg-white rounded-2xl shadow-xs border border-brand-border p-6">
        <h3 className="text-base font-serif font-bold text-brand-charcoal flex items-center gap-2 mb-4">
          <span className="w-6 h-6 rounded-lg bg-brand-green/10 text-brand-green flex items-center justify-center text-xs font-bold font-sans">1</span>
          确认陪伴的长辈
        </h3>

        {elders.length === 0 ? (
          <div className="bg-brand-accent/5 border border-brand-accent/20 rounded-xl p-4 flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-brand-accent shrink-0 mt-0.5" />
            <div>
              <p className="text-sm text-brand-charcoal font-bold">您还没有创建长辈档案</p>
              <p className="text-xs text-brand-charcoal/70 mt-1">请先在上方「长辈信息档案」中点击「新增长辈」，填写好信息后再进行预约。</p>
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            <label className="block text-xs font-medium text-brand-charcoal/60">选择服务对象：</label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {elders.map((elder) => (
                <div
                  key={elder.id}
                  id={`select-elder-option-${elder.id}`}
                  onClick={() => setSelectedElder(elder)}
                  className={`cursor-pointer rounded-xl p-3.5 border transition-all flex items-center gap-3 ${
                    selectedElder?.id === elder.id
                      ? 'border-brand-green bg-brand-green/5 text-brand-charcoal font-semibold shadow-xs'
                      : 'border-brand-border hover:bg-brand-warm-gray/50 text-brand-charcoal/80'
                  }`}
                >
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold shrink-0 ${
                    selectedElder?.id === elder.id ? 'bg-brand-green text-white' : 'bg-brand-warm-gray text-brand-charcoal/60'
                  }`}>
                    {elder.name.substring(0, 1)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold truncate">{elder.name} ({elder.relation})</p>
                    <p className="text-xs text-brand-charcoal/60 truncate">{elder.address}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* 2. Service Catalog */}
      <div className="bg-white rounded-2xl shadow-xs border border-brand-border p-6">
        <h3 className="text-base font-serif font-bold text-brand-charcoal flex items-center gap-2 mb-4">
          <span className="w-6 h-6 rounded-lg bg-brand-green/10 text-brand-green flex items-center justify-center text-xs font-bold font-sans">2</span>
          选择关爱服务
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {SERVICES.map((serv) => {
            const isSelected = selectedService.id === serv.id;
            return (
              <div
                key={serv.id}
                id={`service-select-${serv.id}`}
                onClick={() => handleServiceChange(serv.id)}
                className={`cursor-pointer rounded-2xl p-4 border transition-all flex flex-col justify-between ${
                  isSelected
                    ? 'border-brand-green bg-brand-green/5'
                    : 'border-brand-border hover:border-brand-green/30 bg-white'
                }`}
              >
                <div>
                  <div className="flex items-start justify-between">
                    <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                      isSelected ? 'bg-brand-green text-white' : 'bg-brand-warm-gray text-brand-charcoal/70'
                    }`}>
                      {serv.tag}
                    </span>
                    <span className="text-sm font-bold text-brand-accent">
                      ¥{serv.pricePerHour}/小时
                    </span>
                  </div>
                  <h4 className="text-sm font-bold text-brand-charcoal mt-2 font-serif">{serv.title}</h4>
                  <p className="text-xs text-brand-charcoal/70 mt-1.5 leading-relaxed">{serv.description}</p>
                </div>

                <div className="mt-3.5 pt-3 border-t border-brand-border flex flex-wrap gap-1">
                  {serv.features.slice(0, 3).map((f, i) => (
                    <span key={i} className="text-[10px] bg-brand-sand text-brand-charcoal/60 px-1.5 py-0.5 rounded-md border border-brand-border/40">
                      • {f}
                    </span>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 3. Duration & Gifts */}
      <div className="bg-white rounded-2xl shadow-xs border border-brand-border p-6 space-y-6">
        <div>
          <h3 className="text-base font-serif font-bold text-brand-charcoal flex items-center gap-2 mb-4">
            <span className="w-6 h-6 rounded-lg bg-brand-green/10 text-brand-green flex items-center justify-center text-xs font-bold font-sans">3</span>
            时间与慰问礼品
          </h3>

          {/* Duration Booking (Starts at 30 minutes) */}
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <label className="text-xs font-medium text-brand-charcoal/80 flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-brand-green" />
                预约时长 (半小时起步预订)：
              </label>
              <span className="text-sm font-bold text-brand-green bg-brand-green/10 px-2.5 py-1 rounded-lg">
                {duration} 小时 ({duration * 60} 分钟)
              </span>
            </div>

            {/* Step selection buttons for duration */}
            <div className="grid grid-cols-5 gap-2">
              {[0.5, 1.0, 1.5, 2.0, 3.0].map((hours) => {
                const isMinValid = hours >= selectedService.minDuration;
                return (
                  <button
                    key={hours}
                    id={`duration-btn-${hours}`}
                    type="button"
                    disabled={!isMinValid}
                    onClick={() => setDuration(hours)}
                    className={`py-2 text-xs font-semibold rounded-xl border transition-all ${
                      !isMinValid
                        ? 'bg-brand-warm-gray/40 text-brand-charcoal/30 border-brand-border cursor-not-allowed'
                        : duration === hours
                        ? 'bg-brand-green text-white border-brand-green shadow-xs'
                        : 'bg-white text-brand-charcoal/80 border-brand-border hover:bg-brand-warm-gray'
                    }`}
                  >
                    {hours}h {hours === 0.5 ? '(30分)' : ''}
                  </button>
                );
              })}
            </div>
            {duration < selectedService.minDuration && (
              <p className="text-[10px] text-red-500 flex items-center gap-1 mt-1">
                <AlertCircle className="w-3.5 h-3.5" /> 该服务起步预约时长为 {selectedService.minDuration} 小时。
              </p>
            )}
          </div>
        </div>

        {/* Gift Selection */}
        <div className="space-y-3 border-t border-brand-border pt-5">
          <label className="text-xs font-medium text-brand-charcoal/80 flex items-center gap-1.5 mb-1">
            <Gift className="w-4 h-4 text-brand-green" />
            送礼寒暄：挑选给长辈的慰问品 (包含在本次上门服务中)
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {COMFORT_GIFTS.map((g) => {
              const isSelected = selectedGift.id === g.id;
              return (
                <div
                  key={g.id}
                  id={`gift-select-${g.id}`}
                  onClick={() => setSelectedGift(g)}
                  className={`cursor-pointer rounded-xl p-3 border flex items-start gap-3 transition-all ${
                    isSelected
                      ? 'border-brand-green bg-brand-green/5'
                      : 'border-brand-border hover:border-brand-green/30 bg-white'
                  }`}
                >
                  <div className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${
                    isSelected ? 'bg-brand-green/10 text-brand-green' : 'bg-brand-warm-gray text-brand-charcoal/60'
                  }`}>
                    <Gift className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <p className="text-xs font-bold text-brand-charcoal truncate">{g.name}</p>
                      <span className="text-xs font-bold text-brand-accent shrink-0">
                        {g.price > 0 ? `+¥${g.price}` : '免费'}
                      </span>
                    </div>
                    <p className="text-[10px] text-brand-charcoal/60 mt-1 line-clamp-1">{g.description}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* 4. Preferences setting (The requested user preference feature!) */}
      <div className="bg-white rounded-2xl shadow-xs border border-brand-border p-6 space-y-5">
        <h3 className="text-base font-serif font-bold text-brand-charcoal flex items-center gap-2">
          <span className="w-6 h-6 rounded-lg bg-brand-green/10 text-brand-green flex items-center justify-center text-xs font-bold font-sans">4</span>
          暖心偏好设置 (独家定制)
        </h3>

        {/* Companion Style Preference */}
        <div className="space-y-2">
          <label className="block text-xs font-medium text-brand-charcoal/80">期望陪护师性格风格：</label>
          <div className="grid grid-cols-3 gap-2">
            {['温柔细致', '热情幽默', '沉稳沉静'].map((p) => (
              <button
                key={p}
                id={`pref-personality-${p}`}
                type="button"
                onClick={() => setCompanionPersonality(p)}
                className={`py-2 text-xs font-semibold rounded-xl border transition-all ${
                  companionPersonality === p
                    ? 'bg-brand-green/10 text-brand-green border-brand-green/40'
                    : 'bg-white text-brand-charcoal/80 border-brand-border hover:bg-brand-warm-gray'
                }`}
              >
                {p}
              </button>
            ))}
          </div>
        </div>

        {/* Favorite Topics (Multiple Selection) */}
        <div className="space-y-2">
          <label className="block text-xs font-medium text-brand-charcoal/80">
            建议聊天话题 (多选，陪护师将重点围绕这些话题寒暄)：
          </label>
          <div className="flex flex-wrap gap-2">
            {ALL_TOPICS.map((topic) => {
              const isSelected = selectedTopics.includes(topic);
              return (
                <button
                  key={topic}
                  id={`pref-topic-${topic}`}
                  type="button"
                  onClick={() => toggleTopic(topic)}
                  className={`px-3 py-1.5 text-xs rounded-lg border transition-all ${
                    isSelected
                      ? 'bg-brand-green text-white border-brand-green shadow-xs'
                      : 'bg-brand-sand text-brand-charcoal/80 border-brand-border hover:bg-brand-warm-gray'
                  }`}
                >
                  {topic}
                </button>
              );
            })}
          </div>
        </div>

        {/* Taboo topics (Critical for Elderly comfort) */}
        <div className="space-y-1.5">
          <label className="text-xs font-medium text-brand-charcoal/80 flex items-center gap-1.5">
            <MessageCircleOff className="w-4 h-4 text-brand-charcoal/50" />
            忌讳/避讳话题 (如有请填写)：
          </label>
          <input
            id="input-taboo-topics"
            type="text"
            placeholder="例如：不谈及已故老伴、切勿询问退休金或收入、长辈听力不好请大声..."
            value={tabooTopics}
            onChange={(e) => setTabooTopics(e.target.value)}
            className="w-full bg-brand-sand/50 border border-brand-border rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-brand-green text-brand-charcoal"
          />
        </div>

        {/* Special Instructions */}
        <div className="space-y-1.5">
          <label className="block text-xs font-medium text-brand-charcoal/80 font-sans">长辈习惯与特殊嘱咐：</label>
          <textarea
            id="input-special-instructions"
            rows={2}
            placeholder="例如：长辈喜饮温白开水，不要塞给他喝凉水。散步请带好拐杖，下楼注意慢一点..."
            value={specialInstructions}
            onChange={(e) => setSpecialInstructions(e.target.value)}
            className="w-full bg-brand-sand/50 border border-brand-border rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-brand-green text-brand-charcoal"
          />
        </div>
      </div>

      {/* 5. Date & Time Selection */}
      <div className="bg-white rounded-2xl shadow-xs border border-brand-border p-6 space-y-4">
        <h3 className="text-base font-serif font-bold text-brand-charcoal flex items-center gap-2">
          <span className="w-6 h-6 rounded-lg bg-brand-green/10 text-brand-green flex items-center justify-center text-xs font-bold font-sans">5</span>
          服务时间安排
        </h3>

        <div className="grid grid-cols-3 gap-2">
          <button
            id="time-date-today"
            type="button"
            onClick={() => setScheduledDate('today')}
            className={`py-2.5 text-xs font-semibold rounded-xl border transition-all ${
              scheduledDate === 'today'
                ? 'bg-brand-green text-white border-brand-green shadow-xs'
                : 'bg-white text-brand-charcoal/80 border-brand-border hover:bg-brand-warm-gray'
            }`}
          >
            今天 (7月12日)
          </button>
          <button
            id="time-date-tomorrow"
            type="button"
            onClick={() => setScheduledDate('tomorrow')}
            className={`py-2.5 text-xs font-semibold rounded-xl border transition-all ${
              scheduledDate === 'tomorrow'
                ? 'bg-brand-green text-white border-brand-green shadow-xs'
                : 'bg-white text-brand-charcoal/80 border-brand-border hover:bg-brand-warm-gray'
            }`}
          >
            明天 (7月13日)
          </button>
          <button
            id="time-date-custom"
            type="button"
            onClick={() => setScheduledDate('custom')}
            className={`py-2.5 text-xs font-semibold rounded-xl border transition-all ${
              scheduledDate === 'custom'
                ? 'bg-brand-green text-white border-brand-green shadow-xs'
                : 'bg-white text-brand-charcoal/80 border-brand-border hover:bg-brand-warm-gray'
            }`}
          >
            自定义日期
          </button>
        </div>

        {scheduledDate === 'custom' && (
          <div className="flex gap-2 animate-fadeIn">
            <input
              id="input-custom-date"
              type="date"
              value={customDate}
              onChange={(e) => setCustomDate(e.target.value)}
              className="w-full bg-brand-sand/50 border border-brand-border rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-brand-green text-brand-charcoal"
              required={scheduledDate === 'custom'}
            />
          </div>
        )}

        <div className="space-y-1.5">
          <label className="block text-xs font-medium text-brand-charcoal/80">服务时间段：</label>
          <select
            id="select-time-slot"
            value={scheduledTimeSlot}
            onChange={(e) => setScheduledTimeSlot(e.target.value)}
            className="w-full bg-brand-sand/50 border border-brand-border rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-brand-green text-brand-charcoal"
          >
            <option value="09:00 - 10:30">上午组 09:00 - 10:30</option>
            <option value="10:00 - 11:30">上午组 10:00 - 11:30</option>
            <option value="14:00 - 15:30">下午组 14:00 - 15:30</option>
            <option value="15:30 - 17:00">下午组 15:30 - 17:00</option>
            <option value="19:00 - 20:30">晚间陪伴组 19:00 - 20:30</option>
          </select>
        </div>
      </div>

      {/* Bill summary and checkout */}
      <div className="bg-brand-charcoal text-white rounded-3xl p-6 shadow-sm flex flex-col sm:flex-row justify-between items-center gap-4 border border-brand-border/10">
        <div className="space-y-1.5 text-center sm:text-left">
          <p className="text-xs text-brand-sand/65">预估费用总计</p>
          <div className="flex items-baseline justify-center sm:justify-start gap-1">
            <span className="text-3xl font-serif font-bold text-brand-accent">¥ {calculateTotal()}</span>
            <span className="text-xs text-brand-sand/50">元</span>
          </div>
          <p className="text-[10px] text-brand-sand/60">
            服务：{selectedService.pricePerHour}元/h × {duration}h + 慰问礼：{selectedGift.price}元
          </p>
        </div>

        <button
          id="btn-submit-booking"
          type="submit"
          className="w-full sm:w-auto px-8 py-3.5 bg-brand-green hover:bg-brand-green/90 text-white text-sm font-bold rounded-2xl shadow-xs transition-all flex items-center justify-center gap-2 cursor-pointer"
        >
          <Sparkles className="w-4 h-4 fill-white/10" /> 立即预约孝心上门
        </button>
      </div>

      <div className="flex items-center gap-2 justify-center text-xs text-brand-charcoal/60">
        <ShieldCheck className="w-4 h-4 text-brand-green" />
        <span>百万级养老家政险护航，上门人员均通过公安实名背景审查。</span>
      </div>
    </form>
  );
}

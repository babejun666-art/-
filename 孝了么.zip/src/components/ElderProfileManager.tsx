/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Elder } from '../types';
import { User, Plus, Trash2, Phone, MapPin, Heart, ShieldAlert, Sparkles, Check, Smile } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface ElderProfileManagerProps {
  elders: Elder[];
  onAddElder: (elder: Elder) => void;
  onDeleteElder: (id: string) => void;
  selectedElderId: string | null;
  onSelectElder: (id: string) => void;
}

export default function ElderProfileManager({
  elders,
  onAddElder,
  onDeleteElder,
  selectedElderId,
  onSelectElder
}: ElderProfileManagerProps) {
  const [showForm, setShowForm] = useState(false);
  const [name, setName] = useState('');
  const [age, setAge] = useState<number>(75);
  const [gender, setGender] = useState<'male' | 'female'>('male');
  const [relation, setRelation] = useState('父亲');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [hobbies, setHobbies] = useState('');
  const [personality, setPersonality] = useState('');
  const [healthNotice, setHealthNotice] = useState('');
  const [emergencyContactName, setEmergencyContactName] = useState('');
  const [emergencyContactPhone, setEmergencyContactPhone] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !relation || !phone || !address) {
      alert('请填写姓名、关系、联系电话和居住地址！');
      return;
    }

    const newElder: Elder = {
      id: 'elder_' + Date.now(),
      name,
      age: Number(age),
      gender,
      relation,
      phone,
      address,
      hobbies: hobbies ? hobbies.split(/[，,、\s]+/).filter(Boolean) : [],
      personality: personality || '性格随和',
      healthNotice: healthNotice || '身体健康，行动方便',
      emergencyContactName: emergencyContactName || undefined,
      emergencyContactPhone: emergencyContactPhone || undefined
    };

    onAddElder(newElder);
    resetForm();
  };

  const resetForm = () => {
    setName('');
    setAge(75);
    setGender('male');
    setRelation('父亲');
    setPhone('');
    setAddress('');
    setHobbies('');
    setPersonality('');
    setHealthNotice('');
    setEmergencyContactName('');
    setEmergencyContactPhone('');
    setShowForm(false);
  };

  return (
    <div id="elder-profile-manager" className="bg-white rounded-2xl shadow-sm border border-orange-100 p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
            <Heart className="w-5 h-5 text-orange-500 fill-orange-500/10" />
            长辈信息档案
          </h2>
          <p className="text-xs text-slate-500 mt-1">保存长辈的健康与性格偏好，方便快速下单</p>
        </div>
        <button
          id="btn-toggle-add-elder"
          onClick={() => setShowForm(!showForm)}
          className={`flex items-center gap-1 text-sm font-medium px-3 py-1.5 rounded-xl transition-all ${
            showForm
              ? 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              : 'bg-orange-500 text-white hover:bg-orange-600 shadow-sm shadow-orange-500/20'
          }`}
        >
          {showForm ? '取消' : <><Plus className="w-4 h-4" /> 新增长辈</>}
        </button>
      </div>

      <AnimatePresence mode="wait">
        {showForm ? (
          <motion.form
            id="form-add-elder"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.2 }}
            onSubmit={handleSubmit}
            className="bg-orange-50/50 rounded-2xl p-5 border border-orange-100/60 mb-6 space-y-4 overflow-hidden"
          >
            <h3 className="text-sm font-semibold text-orange-800 flex items-center gap-1">
              <Sparkles className="w-4 h-4 text-orange-600" />
              创建新的长辈档案
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">长辈姓名 <span className="text-red-500">*</span></label>
                <input
                  id="input-elder-name"
                  type="text"
                  placeholder="如：张建国"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-orange-500 text-slate-800"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">关系 <span className="text-red-500">*</span></label>
                <select
                  id="select-elder-relation"
                  value={relation}
                  onChange={(e) => setRelation(e.target.value)}
                  className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-orange-500 text-slate-800"
                >
                  <option value="父亲">父亲</option>
                  <option value="母亲">母亲</option>
                  <option value="爷爷">爷爷</option>
                  <option value="奶奶">奶奶</option>
                  <option value="外公">外公</option>
                  <option value="外婆">外婆</option>
                  <option value="岳父">岳父</option>
                  <option value="岳母">岳母</option>
                  <option value="其他">其他长辈</option>
                </select>
              </div>

              <div className="flex gap-4">
                <div className="flex-1">
                  <label className="block text-xs font-medium text-slate-600 mb-1">年龄</label>
                  <input
                    id="input-elder-age"
                    type="number"
                    min="50"
                    max="120"
                    value={age}
                    onChange={(e) => setAge(Number(e.target.value))}
                    className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-orange-500 text-slate-800"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1">性别</label>
                  <div className="flex bg-slate-100 rounded-xl p-1 mt-0.5">
                    <button
                      id="btn-gender-male"
                      type="button"
                      onClick={() => setGender('male')}
                      className={`px-3 py-1 text-xs font-medium rounded-lg transition-all ${
                        gender === 'male' ? 'bg-white text-orange-600 shadow-xs' : 'text-slate-500'
                      }`}
                    >
                      男
                    </button>
                    <button
                      id="btn-gender-female"
                      type="button"
                      onClick={() => setGender('female')}
                      className={`px-3 py-1 text-xs font-medium rounded-lg transition-all ${
                        gender === 'female' ? 'bg-white text-orange-600 shadow-xs' : 'text-slate-500'
                      }`}
                    >
                      女
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">联系电话 <span className="text-red-500">*</span></label>
                <input
                  id="input-elder-phone"
                  type="tel"
                  placeholder="长辈或家中固话/看护手机"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-orange-500 text-slate-800"
                  required
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">居住地址 <span className="text-red-500">*</span></label>
                <input
                  id="input-elder-address"
                  type="text"
                  placeholder="详细上门服务地址"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-orange-500 text-slate-800"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">紧急联系人姓名</label>
                <input
                  id="input-elder-emergency-name"
                  type="text"
                  placeholder="如：儿子 张海松"
                  value={emergencyContactName}
                  onChange={(e) => setEmergencyContactName(e.target.value)}
                  className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-orange-500 text-slate-800"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">紧急联系人电话</label>
                <input
                  id="input-elder-emergency-phone"
                  type="tel"
                  placeholder="紧急情况下可一键拨打"
                  value={emergencyContactPhone}
                  onChange={(e) => setEmergencyContactPhone(e.target.value)}
                  className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-orange-500 text-slate-800"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">长辈爱好 (逗号/空格分隔)</label>
                <input
                  id="input-elder-hobbies"
                  type="text"
                  placeholder="如：读报、听京剧、下象棋"
                  value={hobbies}
                  onChange={(e) => setHobbies(e.target.value)}
                  className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-orange-500 text-slate-800"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">性格特点</label>
                <input
                  id="input-elder-personality"
                  type="text"
                  placeholder="如：开朗健谈、有些严肃"
                  value={personality}
                  onChange={(e) => setPersonality(e.target.value)}
                  className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-orange-500 text-slate-800"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">健康/防摔注意事项</label>
                <input
                  id="input-elder-health"
                  type="text"
                  placeholder="如：腿脚不便需拐杖、高血压"
                  value={healthNotice}
                  onChange={(e) => setHealthNotice(e.target.value)}
                  className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-orange-500 text-slate-800"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-orange-100">
              <button
                id="btn-cancel-elder"
                type="button"
                onClick={resetForm}
                className="px-4 py-2 text-xs font-medium text-slate-500 hover:text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-all"
              >
                取消
              </button>
              <button
                id="btn-save-elder"
                type="submit"
                className="px-5 py-2 text-xs font-medium text-white bg-orange-500 hover:bg-orange-600 rounded-xl shadow-xs transition-all"
              >
                保存档案
              </button>
            </div>
          </motion.form>
        ) : null}
      </AnimatePresence>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {elders.map((elder) => {
          const isSelected = selectedElderId === elder.id;
          return (
            <motion.div
              key={elder.id}
              id={`elder-card-${elder.id}`}
              layout
              onClick={() => onSelectElder(elder.id)}
              className={`relative cursor-pointer rounded-2xl p-4 border transition-all flex flex-col justify-between ${
                isSelected
                  ? 'border-orange-500 bg-orange-50/40 shadow-sm shadow-orange-500/5'
                  : 'border-slate-100 bg-slate-50/50 hover:bg-slate-50 hover:border-slate-200'
              }`}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center text-lg font-bold ${
                    elder.gender === 'male' ? 'bg-blue-100 text-blue-600' : 'bg-pink-100 text-pink-600'
                  }`}>
                    {elder.name.substring(0, 1)}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-800 text-sm">{elder.name}</span>
                      <span className="text-[10px] bg-slate-200/70 text-slate-600 px-1.5 py-0.5 rounded-md font-medium">
                        {elder.relation}
                      </span>
                      {isSelected && (
                        <span className="text-[10px] bg-orange-500 text-white px-1.5 py-0.5 rounded-md font-medium flex items-center gap-0.5">
                          <Check className="w-3 h-3" /> 已选
                        </span>
                      )}
                    </div>
                    <span className="text-xs text-slate-500">
                      {elder.gender === 'male' ? '男' : '女'} · {elder.age}岁
                    </span>
                  </div>
                </div>

                <button
                  id={`btn-delete-elder-${elder.id}`}
                  onClick={(e) => {
                    e.stopPropagation();
                    if (confirm(`确认要删除${elder.name}的档案吗？`)) {
                      onDeleteElder(elder.id);
                    }
                  }}
                  className="text-slate-400 hover:text-red-500 p-1.5 rounded-lg hover:bg-red-50 transition-all"
                  title="删除档案"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100/80 space-y-2">
                <div className="flex items-center gap-1.5 text-xs text-slate-600">
                  <Phone className="w-3.5 h-3.5 text-slate-400" />
                  <span>{elder.phone}</span>
                </div>
                <div className="flex items-start gap-1.5 text-xs text-slate-600">
                  <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                  <span className="line-clamp-1">{elder.address}</span>
                </div>
                {elder.emergencyContactName && (
                  <div className="flex items-center gap-1.5 text-xs text-amber-700 font-medium">
                    <ShieldAlert className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                    <span>紧急：{elder.emergencyContactName} ({elder.emergencyContactPhone || '无电话'})</span>
                  </div>
                )}
              </div>

              {/* Hobbies and Notices */}
              <div className="mt-3 flex flex-wrap gap-1">
                {elder.hobbies.map((h, idx) => (
                  <span key={idx} className="text-[10px] bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded-md">
                    {h}
                  </span>
                ))}
                <span className="text-[10px] bg-amber-50 text-amber-700 px-1.5 py-0.5 rounded-md font-medium flex items-center gap-0.5 border border-amber-100/60">
                  <Smile className="w-3 h-3 shrink-0" /> {elder.personality}
                </span>
              </div>

              {elder.healthNotice && (
                <div className="mt-2.5 bg-red-50/50 border border-red-100/60 rounded-xl p-2 flex items-start gap-1.5">
                  <ShieldAlert className="w-3.5 h-3.5 text-red-500 shrink-0 mt-0.5" />
                  <p className="text-[10px] text-red-700 leading-normal">{elder.healthNotice}</p>
                </div>
              )}
            </motion.div>
          );
        })}
        {elders.length === 0 && (
          <div className="col-span-2 py-10 flex flex-col items-center justify-center text-slate-400 bg-slate-50 rounded-2xl border border-dashed border-slate-200">
            <User className="w-10 h-10 mb-2 stroke-1" />
            <p className="text-sm">暂无长辈档案，点击右上角新增一个吧！</p>
          </div>
        )}
      </div>
    </div>
  );
}

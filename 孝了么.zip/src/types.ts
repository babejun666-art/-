/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Elder {
  id: string;
  name: string;
  age: number;
  gender: 'male' | 'female';
  relation: string; // e.g., '父亲', '母亲', '爷爷', '奶奶', '外公', '外婆'
  phone: string;
  address: string;
  hobbies: string[]; // e.g., ['看京剧', '下象棋', '养花', '时事政治']
  personality: string; // e.g., '开朗健谈', '温和安静', '严肃认真', '记性好'
  healthNotice: string; // Health or mobility warnings
  emergencyContactName?: string; // Emergency contact name
  emergencyContactPhone?: string; // Emergency contact phone number
}

export type ServiceType = 'greeting' | 'reading' | 'walking' | 'housework' | 'care';

export interface ServiceItem {
  id: ServiceType;
  title: string;
  icon: string; // Lucide icon name
  description: string;
  pricePerHour: number;
  minDuration: number; // in hours, e.g., 0.5 for half an hour
  tag: string;
  features: string[];
}

export interface Companion {
  id: string;
  name: string;
  avatar: string; // SVG seed or standard initials
  age: number;
  rating: number;
  experienceYears: number;
  tags: string[]; // e.g., ['耐心细致', '会说粤语', '擅长做粤菜', '红十字急救证']
  bio: string;
}

export interface ComfortGift {
  id: string;
  name: string;
  price: number;
  description: string;
  category: 'fruit' | 'food' | 'flower' | 'health' | 'none';
  icon: string;
}

export interface BookingPreference {
  companionPersonality: string; // e.g., '热情幽默', '温柔细致', '沉稳沉静'
  chatTopics: string[]; // Topics preferred: e.g., ['当年旧事', '儿女近况', '养生保健', '新闻时事']
  tabooTopics: string; // Topics to avoid, e.g., '不谈及病情、不要问退休金'
  specialInstructions: string; // Other requests
}

export type OrderStatus = 'pending' | 'matched' | 'ongoing' | 'completed' | 'cancelled';

export interface OrderTimelineStep {
  title: string;
  time: string;
  description: string;
  status: 'done' | 'current' | 'upcoming';
}

export interface Order {
  id: string;
  elder: Elder;
  service: ServiceItem;
  gift?: ComfortGift;
  durationHours: number; // e.g. 0.5, 1.0, 1.5 etc.
  scheduledTime: string;
  totalPrice: number;
  preference: BookingPreference;
  status: OrderStatus;
  companion?: Companion;
  createdAt: string;
  timeline: OrderTimelineStep[];
  visitReport?: {
    elderStatus: string; // '心情舒畅', '略显疲惫', '食欲大好' 等
    activityLog: string[]; // e.g., ['送达了无糖糕点，长辈很高兴', '陪长辈读了15分钟《人民日报》', '在楼下小花园散步一圈，聊了当年的工作经历']
    companionNotes: string; // Long text feedback from companion to the younger user
    photos?: string[]; // Visual feedback placeholders
  };
}

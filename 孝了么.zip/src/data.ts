/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ServiceItem, ComfortGift, Companion, Elder, Order } from './types';

export const SERVICES: ServiceItem[] = [
  {
    id: 'greeting',
    title: '上门赠送慰问品与暖心寒暄',
    icon: 'Gift',
    description: '专业陪护师携带自选慰问品上门，与长辈进行暖心聊天、嘘寒问暖，舒缓心理寂寞。',
    pricePerHour: 98,
    minDuration: 0.5,
    tag: '半小时起步预订',
    features: ['自选精美慰问品', '亲切方言交流', '拉家常倾听旧事', '半小时快速陪伴']
  },
  {
    id: 'reading',
    title: '暖心读报与时事闲聊',
    icon: 'BookOpen',
    description: '陪同长辈阅读每日报纸、杂志、或诵读经典文学，畅聊国内外时事与文化话题，保持思维活跃。',
    pricePerHour: 80,
    minDuration: 1.0,
    tag: '阅读沟通',
    features: ['主流报纸阅读', '方言/普通话朗读', '时事探讨聊天', '解答手机使用疑问']
  },
  {
    id: 'walking',
    title: '户外散步与阳光陪护',
    icon: 'TreePine',
    description: '协助长辈下楼，在社区公园或附近街区安全散步。呼吸新鲜空气，适度伸展身体。',
    pricePerHour: 88,
    minDuration: 1.0,
    tag: '健康适度运动',
    features: ['全程轮椅/搀扶看护', '速度舒缓监测', '户外赏花赏景', '预防跌倒安全急救准备']
  },
  {
    id: 'housework',
    title: '家务整理与爱心陪伴',
    icon: 'Sparkles',
    description: '帮助长辈进行居家整理，如扫地、擦桌、衣物折叠、冰箱过期食品清理，共同创造温馨整洁的环境。',
    pricePerHour: 85,
    minDuration: 1.0,
    tag: '居家清洁',
    features: ['客厅/卧室轻度整理', '防滑隐患排查', '协助衣物收纳', '聊天谈心']
  },
  {
    id: 'care',
    title: '医院陪护与陪诊无忧',
    icon: 'Stethoscope',
    description: '全程陪同长辈就医挂号、缴费、取药、取报告、指引诊室，详细记录医嘱并向子女反馈。',
    pricePerHour: 110,
    minDuration: 2.0,
    tag: '就医绿通',
    features: ['提前协助预约挂号', '轮椅推行与站立搀扶', '诊间贴身陪伴', '整理医生服药叮嘱']
  }
];

export const COMFORT_GIFTS: ComfortGift[] = [
  {
    id: 'gift_fruit_basket',
    name: '【心意满满】时令低糖水果果篮',
    price: 68,
    description: '精选无糖、低糖水果（如苹果、奇异果、小番茄），健康养生。',
    category: 'fruit',
    icon: 'Apple'
  },
  {
    id: 'gift_pastry',
    name: '【传统美味】稻香村手工无糖糕点',
    price: 45,
    description: '松软易嚼，专为长辈烘焙的无糖健康粗粮糕点礼盒。',
    category: 'food',
    icon: 'Cookie'
  },
  {
    id: 'gift_tea',
    name: '【茶香悠然】高山茉莉花茶/菊花茶礼盒',
    price: 58,
    description: '清热降火，包装简朴雅致，适合长辈饮用和闻香。',
    category: 'food',
    icon: 'CupSoda'
  },
  {
    id: 'gift_flower',
    name: '【常青祝愿】康乃馨与暖色向日葵花束',
    price: 49,
    description: '代表感恩与健康的鲜花组合，为家里增添一抹温馨亮色。',
    category: 'flower',
    icon: 'Flower'
  },
  {
    id: 'gift_kneepad',
    name: '【保暖贴心】自发热老寒腿护膝一套',
    price: 39,
    description: '防寒保暖，材质柔软，送给关节怕冷的长辈最贴心的实用之选。',
    category: 'health',
    icon: 'HeartPulse'
  },
  {
    id: 'gift_none',
    name: '暂不需要送礼（仅需暖心服务）',
    price: 0,
    description: '仅预约上门陪伴、寒暄和专业服务。',
    category: 'none',
    icon: 'Smile'
  }
];

export const COMPANIONS: Companion[] = [
  {
    id: 'comp_zhang_yulan',
    name: '张玉兰阿姨',
    avatar: '👩‍🦳',
    age: 48,
    rating: 4.9,
    experienceYears: 6,
    tags: ['温柔亲切', '擅长上海话', '擅长京剧闲聊', '初级护士证'],
    bio: '从事家政与养老陪护多年，性格爽朗，非常懂得倾听。平时爱看戏、爱聊天，擅长用大白话逗长辈开心，能提供家务指导和轻度心理抚慰。'
  },
  {
    id: 'comp_li_qiang',
    name: '李强小哥',
    avatar: '👨',
    age: 32,
    rating: 4.8,
    experienceYears: 4,
    tags: ['身强体壮', '陪诊高效', '擅长推拿按摩', '红十字急救员'],
    bio: '有医院护理辅助背景，做事沉稳麻利。擅长推轮椅、陪诊挂号，能背着腿脚不便的长辈上下楼，对各大医院流程极其熟悉，十分细心。'
  },
  {
    id: 'comp_wang_shufen',
    name: '王淑芬阿姨',
    avatar: '👵',
    age: 51,
    rating: 5.0,
    experienceYears: 8,
    tags: ['耐心极好', '擅长粤语/客家话', '精通慢病饮食', '资深心理辅导者'],
    bio: '已退休的前社区社工，擅长和孤寂、有焦虑情绪的老人沟通。极具耐心，擅长通过读报、聊历史拉近关系，也能细心排查老人的家庭隐患。'
  },
  {
    id: 'comp_chen_ran',
    name: '陈然老师',
    avatar: '👩‍🎓',
    age: 26,
    rating: 4.9,
    experienceYears: 3,
    tags: ['大学生志愿者', '充满朝气', '爱拉小提琴', '手机使用指导'],
    bio: '社会工作专业研究生毕业，性格活泼阳光。特别擅长教爷爷奶奶用微信、刷视频、看新闻。可以用年轻人的活力感染长辈，给老两口带去新欢笑。'
  }
];

export const DEFAULT_ELDERS: Elder[] = [
  {
    id: 'elder_1',
    name: '张建国 (爷爷)',
    age: 78,
    gender: 'male',
    relation: '爷爷',
    phone: '13812345678',
    address: '上海市徐汇区天平路街道建国新村3号楼202室',
    hobbies: ['时事政治', '读报纸', '泡脚养生', '谈老厂长往事'],
    personality: '性格有些倔强但内心柔软，喜欢和年轻人谈论以前支援三线建设的功绩，看报纸只看大新闻。',
    healthNotice: '患有高血压，右腿膝关节炎，下楼行走最好带拐杖或用轮椅。',
    emergencyContactName: '张海松 (儿子)',
    emergencyContactPhone: '13566667777'
  },
  {
    id: 'elder_2',
    name: '李秀珍 (姥姥)',
    age: 82,
    gender: 'female',
    relation: '外婆',
    phone: '13987654321',
    address: '上海市长宁区愚园路1020号里弄5弄',
    hobbies: ['养兰花', '听越剧', '包江浙馄饨', '看家庭伦理剧'],
    personality: '温和优雅，健谈好客，特别喜欢家里热热闹闹的，听到老越剧调子会忍不住跟着哼。',
    healthNotice: '轻度帕金森导致手有点抖，需要防滑环境，情绪不能过于激动。',
    emergencyContactName: '王丽华 (女儿)',
    emergencyContactPhone: '13688889999'
  }
];

export const SAMPLE_ORDERS: Order[] = [
  {
    id: 'order_1',
    elder: DEFAULT_ELDERS[0],
    service: SERVICES[0], // 暖心寒暄
    gift: COMFORT_GIFTS[1], // 稻香村糕点
    durationHours: 1.0,
    scheduledTime: '今天 10:00 - 11:00',
    totalPrice: 143, // 98 * 1 + 45
    preference: {
      companionPersonality: '温柔细致',
      chatTopics: ['当年旧事', '国家大事'],
      tabooTopics: '不要主动询问退休金或家庭矛盾，也不要总劝他吃药',
      specialInstructions: '长辈耳朵有点背，说话请大声且慢一些。'
    },
    status: 'ongoing',
    companion: COMPANIONS[0], // 张玉兰
    createdAt: '2026-07-12T08:30:00Z',
    timeline: [
      { title: '订单已提交', time: '08:30', description: '您为张爷爷成功提交了暖心寒暄预约。', status: 'done' },
      { title: '陪护师已就绪', time: '09:00', description: '张玉兰阿姨已接受预约，并领取了【稻香村手工无糖糕点】慰问品。', status: 'done' },
      { title: '服务进行中', time: '10:00', description: '张玉兰阿姨已上门。正把糕点递给张爷爷，并开始聊天。', status: 'current' },
      { title: '总结反馈', time: '11:15', description: '服务结束后，陪护师将撰写今日探望报告并拍摄长辈合影。', status: 'upcoming' }
    ]
  },
  {
    id: 'order_2',
    elder: DEFAULT_ELDERS[1],
    service: SERVICES[2], // 散步陪护
    gift: COMFORT_GIFTS[0], // 养生果篮
    durationHours: 1.5,
    scheduledTime: '明天 15:00 - 16:30',
    totalPrice: 200, // 88 * 1.5 + 68 = 200
    preference: {
      companionPersonality: '沉稳沉静',
      chatTopics: ['花草养殖', '越剧鉴赏'],
      tabooTopics: '无特别禁忌',
      specialInstructions: '最近天热，带外婆散步时请尽量走树荫下，随身带好温开水。'
    },
    status: 'matched',
    companion: COMPANIONS[2], // 王淑芬👵
    createdAt: '2026-07-11T14:20:00Z',
    timeline: [
      { title: '订单已提交', time: '昨日 14:20', description: '您为李外婆成功提交了户外散步服务预约。', status: 'done' },
      { title: '陪护师已匹配', time: '昨日 16:00', description: '王淑芬阿姨（退休社工）已接单，并仔细研究了李外婆的偏好。', status: 'current' },
      { title: '上门服务', time: '明日 15:00', description: '陪护师将准时抵达李外婆家，并带去低糖时令果篮。', status: 'upcoming' },
      { title: '报告提交', time: '明日 16:45', description: '服务结束后提交详实的散步及心理陪伴总结。', status: 'upcoming' }
    ]
  },
  {
    id: 'order_3',
    elder: DEFAULT_ELDERS[0],
    service: SERVICES[4], // 陪诊无忧
    gift: COMFORT_GIFTS[5], // 暂不需要送礼
    durationHours: 3.0,
    scheduledTime: '2026-07-08 08:30 - 11:30',
    totalPrice: 330, // 110 * 3
    preference: {
      companionPersonality: '热情幽默',
      chatTopics: ['儿女近况'],
      tabooTopics: '不要催促长辈，他走路慢容易着急',
      specialInstructions: '华山医院人很多，建国爷爷需要坐在轮椅上排队。已把病历本和社保卡放在门口玄关柜。'
    },
    status: 'completed',
    companion: COMPANIONS[1], // 李强
    createdAt: '2026-07-07T09:00:00Z',
    timeline: [
      { title: '订单已预约', time: '07-07 09:00', description: '预约医院陪护陪诊。', status: 'done' },
      { title: '陪护师接单', time: '07-07 10:15', description: '资深陪诊师李强小哥已接单。', status: 'done' },
      { title: '已抵达陪护', time: '07-08 08:20', description: '李强已抵达建国爷爷家门口，推长辈乘坐无障碍出租车前往医院。', status: 'done' },
      { title: '服务结束', time: '07-08 11:30', description: '就医完成，李强送长辈返回家中，并安顿好药量。', status: 'done' },
      { title: '报告已提交', time: '07-08 12:00', description: '陪护师已向子女提交详细的病历与医生嘱咐报告。', status: 'done' }
    ],
    visitReport: {
      elderStatus: '神志清醒，配合度高，情绪略微焦虑但检查后放松。',
      activityLog: [
        '08:30 顺利接到建国爷爷，协助上无障碍专用车，直达华山医院。',
        '09:10 协助挂号，并在神内二科候诊区陪爷爷聊天，缓解了爷爷害怕检查的焦虑。',
        '10:15 进入诊室，记录了医嘱：继续服用银杏叶片，血压药按原剂量吃。下月15号复查。',
        '11:00 协助缴费、抽血与取药，全程使用医院无障碍设施。',
        '11:30 安全将爷爷送回天平路家，并把今日用药用分药盒装好，贴好标签。'
      ],
      companionNotes: '建国爷爷今天一开始有点紧张，我给他聊了我老家也是三线建设的，他一下子就健谈了，直夸我是个“懂事的小李”。医生开的降压药（拜新同）记得提醒他每天早上吃一粒。爷爷今天走路膝盖有些抖，最近阴雨天要记得提醒他保暖。'
    }
  }
];

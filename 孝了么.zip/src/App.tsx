/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Elder, Order, ServiceType, OrderStatus } from './types';
import { SERVICES, COMFORT_GIFTS, DEFAULT_ELDERS, SAMPLE_ORDERS, COMPANIONS } from './data';
import ElderProfileManager from './components/ElderProfileManager';
import BookingForm from './components/BookingForm';
import OrderTracker from './components/OrderTracker';
import { Heart, Activity, User, Sparkles, ShieldCheck, ClipboardCheck, Phone, Info, Award, HelpCircle, Star, Layers, CalendarCheck } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const [elders, setElders] = useState<Elder[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [selectedElderId, setSelectedElderId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'book' | 'elders' | 'orders'>('book');
  const [lastNotification, setLastNotification] = useState<string | null>(null);

  // Load from LocalStorage
  useEffect(() => {
    const savedElders = localStorage.getItem('xiaoleme_elders');
    const savedOrders = localStorage.getItem('xiaoleme_orders');

    if (savedElders) {
      setElders(JSON.parse(savedElders));
    } else {
      setElders(DEFAULT_ELDERS);
      localStorage.setItem('xiaoleme_elders', JSON.stringify(DEFAULT_ELDERS));
    }

    if (savedOrders) {
      setOrders(JSON.parse(savedOrders));
    } else {
      setOrders(SAMPLE_ORDERS);
      localStorage.setItem('xiaoleme_orders', JSON.stringify(SAMPLE_ORDERS));
    }
  }, []);

  // Sync to LocalStorage
  const saveEldersToStorage = (newElders: Elder[]) => {
    setElders(newElders);
    localStorage.setItem('xiaoleme_elders', JSON.stringify(newElders));
  };

  const saveOrdersToStorage = (newOrders: Order[]) => {
    setOrders(newOrders);
    localStorage.setItem('xiaoleme_orders', JSON.stringify(newOrders));
  };

  // Elder Profile Management Handlers
  const handleAddElder = (newElder: Elder) => {
    const updated = [newElder, ...elders];
    saveEldersToStorage(updated);
    setSelectedElderId(newElder.id);
    showNotification(`已成功为您创建并保存【${newElder.name}】的健康与性格偏好档案！`);
  };

  const handleDeleteElder = (id: string) => {
    const updated = elders.filter(e => e.id !== id);
    saveEldersToStorage(updated);
    if (selectedElderId === id) {
      setSelectedElderId(updated.length > 0 ? updated[0].id : null);
    }
    showNotification('长辈信息档案已成功移除。');
  };

  // Booking handlers
  const handleBookingSuccess = (newOrder: Order) => {
    const updated = [newOrder, ...orders];
    saveOrdersToStorage(updated);
    setActiveTab('orders');
    showNotification(`预订成功！已成功为您和长辈匹配了金牌陪护师【${newOrder.companion?.name}】。`);
  };

  // Cancel order
  const handleCancelOrder = (orderId: string) => {
    const updated = orders.map(o => {
      if (o.id === orderId) {
        return {
          ...o,
          status: 'cancelled' as OrderStatus,
          timeline: [
            ...o.timeline,
            { title: '订单已取消', time: '刚才', description: '您取消了本次陪伴服务，款项已全额退回原账户。', status: 'done' as const }
          ]
        };
      }
      return o;
    });
    saveOrdersToStorage(updated);
    showNotification('本次陪伴服务已被成功取消，款项已退回。');
  };

  // Advanced simulator of order progress (to make the prototype highly realistic and delightful!)
  const handleAdvanceOrderStatus = (orderId: string) => {
    const updated = orders.map(o => {
      if (o.id === orderId) {
        if (o.status === 'matched') {
          // Transition: matched -> ongoing
          return {
            ...o,
            status: 'ongoing' as OrderStatus,
            timeline: o.timeline.map((t, idx) => {
              if (idx === 1) return { ...t, status: 'done' as const };
              if (idx === 2) return { ...t, status: 'current' as const, time: '现在', description: `【${o.companion?.name}】已提着礼品顺利抵达长辈家，正在开心地拉家常中。` };
              return t;
            })
          };
        } else if (o.status === 'ongoing') {
          // Transition: ongoing -> completed
          // Automatically craft custom elder visit summary report based on elder name and service!
          const name = o.elder.name.split(' ')[0];
          const serviceTitle = o.service.title;
          const companionName = o.companion?.name || '陪护师';
          const giftName = o.gift ? o.gift.name : '暖心问候';

          let reportStatus = '心情愉悦，胃口大开';
          let logs: string[] = [];
          let note = '';

          if (o.service.id === 'greeting') {
            reportStatus = '神采奕奕，满脸笑容';
            logs = [
              `1. ${companionName} 准时抵达，将【${giftName}】亲手送上，长辈收到特别高兴。`,
              `2. 围绕长辈偏好的话题【${o.preference.chatTopics.join('、')}】进行了半小时起步的深度寒暄。`,
              `3. 陪长辈在客厅品茶、聊了长辈年轻时工作和儿孙的近况。`
            ];
            note = `${name}今天非常健谈！一听到我提起他以前的事，眼里直放光，拉着我的手讲了大半个钟头。老人家说你们年轻人平时工作忙，他非常理解，但能看到有人特地上门看他、送礼物，心里热乎乎的。老人家血压我顺便测了一下，135/82 处于正常范围，精神头极好！`;
          } else if (o.service.id === 'reading') {
            reportStatus = '求知欲满，谈笑风生';
            logs = [
              `1. 陪同长辈共同翻阅并朗读了最新的一期报纸。`,
              `2. 解答了长辈关于智能手机使用（如清理微信、看视频）的疑惑，教了2遍。`,
              `3. 共同探讨了长辈最关心的时事话题。`
            ];
            note = `${name}对世界大事了解得真多！我们聊时事的时候，老人家头头是道，思维很清晰。我帮他把手机里占内存的微信缓存清理干净了，还把他的手机字体调大了一号，爷爷直夸我细心。老人家让我帮他转告，他在家过得很好，别为他担心，多注意身体！`;
          } else if (o.service.id === 'walking') {
            reportStatus = '步伐稳健，睡眠质量改善';
            logs = [
              `1. 帮长辈披上外套、穿好平底防滑鞋，贴身搀扶下楼。`,
              `2. 在小区绿化带及附近街区公园漫步半小时，呼吸新鲜空气。`,
              `3. 途中在长椅上休息两次，喝温水，晒太阳，聊了聊当年的家常。`
            ];
            note = `今天下午天气好，我扶着${name}在小公园转了转。老人家平时活动少，今天走了一圈出了微微的细汗，特别开心。散步的时候她直夸路边月季花开得好，还教我怎么给兰花浇水。老人家有些风湿老寒腿，我嘱咐他晚上多泡热水脚，回去后他还高高兴兴地多吃了一半的晚饭呢。`;
          } else if (o.service.id === 'housework') {
            reportStatus = '环境整洁，心情舒畅';
            logs = [
              `1. 帮长辈做了客厅及卧室的基础清洁整理，拖地、擦灰。`,
              `2. 协助整理衣柜，将被子和厚重外衣收纳，剔除厨房和冰箱里几包过期调料。`,
              `3. 排查了卫生间地滑等居家安全隐患。`
            ];
            note = `${name}的屋子其实挺干净，主要是有些重物和高处的衣物老人家不方便拿。我帮他把衣柜和杂物柜彻底归纳了一下，把常用药和拐杖放在最显眼的位置。清扫的时候，我们一直在聊天。老人家说看到家里重新亮堂堂的，整个人精气神都不一样了。冰箱里过期的麦片我已经帮他扔掉了，您下次来可以帮老人家买点新的燕麦。`;
          } else {
            reportStatus = '状态平稳，焦虑感降低';
            logs = [
              `1. 陪同前往医院，协助建档、排队挂号与候诊。`,
              `2. 站立搀扶、上下电梯全程贴身保护，安抚长辈就医的紧张情绪。`,
              `3. 整理医生叮嘱，拿药、细致分装并向子女同步。`
            ];
            note = `今天陪同${name}去医院做常规检查。老人家起初嫌麻烦、怕花钱，在候诊室有些焦虑。我一直握着老人的手，给他讲讲笑话、拉家常，老人慢慢就放松下来了。大夫看得很仔细，说指标控制得挺好，继续遵医嘱吃药就行。药已经分类摆在药箱里了。`;
          }

          return {
            ...o,
            status: 'completed' as OrderStatus,
            timeline: [
              ...o.timeline.slice(0, 3).map((t, idx) => {
                if (idx < 3) return { ...t, status: 'done' as const };
                return t;
              }),
              { title: '服务进行中', time: '刚才', description: `【${companionName}】顺利完成陪伴，正与长辈亲切告别。`, status: 'done' as const },
              { title: '完成探望与日志回馈', time: '刚才', description: '本次陪伴圆满结束，探望日志报告及长辈合影已向您呈递。', status: 'done' as const }
            ],
            visitReport: {
              elderStatus: reportStatus,
              activityLog: logs,
              companionNotes: note
            }
          };
        }
      }
      return o;
    });

    saveOrdersToStorage(updated);
    const order = updated.find(o => o.id === orderId);
    if (order?.status === 'ongoing') {
      showNotification(`【${order.companion?.name}】已出发，提着礼物敲开了长辈家门，开始亲切上门服务！`);
    } else if (order?.status === 'completed') {
      showNotification(`陪伴已顺利完成！陪护师【${order.companion?.name}】已撰写了超详细的长辈状况与爱心报告，快去下方订单详情查看吧。`);
    }
  };

  const showNotification = (msg: string) => {
    setLastNotification(msg);
    setTimeout(() => {
      setLastNotification(null);
    }, 5000);
  };

  // Stats block
  const totalCompleted = orders.filter(o => o.status === 'completed').length;
  const activeCount = orders.filter(o => o.status === 'ongoing' || o.status === 'matched').length;

  return (
    <div id="app-container" className="min-h-screen bg-brand-sand text-brand-charcoal font-sans antialiased pb-16">
      {/* 5-second dynamic toast notification */}
      <AnimatePresence>
        {lastNotification && (
          <motion.div
            id="toast-notification"
            initial={{ opacity: 0, y: -50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -50 }}
            className="fixed top-5 left-1/2 -translate-x-1/2 z-50 max-w-md w-full px-4"
          >
            <div className="bg-brand-charcoal text-white rounded-2xl p-4 shadow-xl border border-brand-border/20 flex items-start gap-3">
              <Sparkles className="w-5 h-5 text-brand-accent shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="text-xs text-brand-accent font-bold">系统温馨提示</p>
                <p className="text-xs text-brand-warm-gray mt-1 leading-relaxed">{lastNotification}</p>
              </div>
              <button
                onClick={() => setLastNotification(null)}
                className="text-brand-warm-gray/60 hover:text-white text-xs font-bold px-1.5"
              >
                ✕
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Hero Header Area */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-brand-border sticky top-0 z-30 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 py-3.5 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-brand-green flex items-center justify-center shadow-md">
              <Heart className="w-6 h-6 text-white fill-white/10" />
            </div>
            <div className="text-left">
              <div className="flex items-center gap-2">
                <h1 className="text-2xl font-serif font-bold text-brand-charcoal tracking-tight">孝了么</h1>
                <span className="text-[10px] bg-brand-green/10 text-brand-green px-2 py-0.5 rounded-full font-bold">青年孝心专线</span>
              </div>
              <p className="text-[10px] text-brand-charcoal/60 font-medium">让温情陪伴与问候即刻敲门 · 100%持证专业老龄陪护</p>
            </div>
          </div>

          {/* Slogan & Trust indicators */}
          <div className="flex items-center gap-6 text-xs text-brand-charcoal/70 font-medium flex-wrap justify-center">
            <div className="flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-brand-green" />
              <span>实名背景审查</span>
            </div>
            <div className="flex items-center gap-1.5">
              <CalendarCheck className="w-4 h-4 text-brand-green" />
              <span>灵活弹性预定</span>
            </div>
            <div className="flex items-center gap-1.5">
              <ClipboardCheck className="w-4 h-4 text-brand-green" />
              <span>暖心回馈报告</span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Stats Summary Dashboard Row */}
      <div className="max-w-7xl mx-auto px-4 mt-6">
        <div className="bg-brand-green rounded-[24px] p-6 md:p-8 text-white shadow-sm flex flex-col md:flex-row justify-between items-center gap-6 border border-brand-green/20">
          <div className="text-center md:text-left space-y-2">
            <h2 className="text-xl md:text-2xl font-serif font-bold flex items-center justify-center md:justify-start gap-2">
              <Sparkles className="w-5 h-5 text-brand-accent fill-brand-accent/20 animate-pulse" />
              百忙之中的你，孝心我们为您送达
            </h2>
            <p className="text-xs md:text-sm text-brand-sand/80 leading-relaxed max-w-2xl">
              为长辈预订一次探望、一束鲜花、或陪着散散步、读读报，甚至陪同就医。
              您可随心设置长辈性格偏好、寒暄话题，以及需要避讳的雷区。陪护师上门后，将为您提供详尽的健康与心理反馈。
            </p>
          </div>

          <div className="flex items-center gap-6 bg-white/10 backdrop-blur-md rounded-2xl px-6 py-4.5 shrink-0 justify-around w-full md:w-auto border border-white/10">
            <div className="text-center">
              <p className="text-xs text-brand-sand/70">已建档长辈</p>
              <p className="text-2xl font-serif font-bold mt-1 text-white">{elders.length} <span className="text-xs font-normal text-brand-sand/80">位</span></p>
            </div>
            <div className="w-px h-8 bg-white/20" />
            <div className="text-center">
              <p className="text-xs text-brand-sand/70">进行中服务</p>
              <p className="text-2xl font-serif font-bold mt-1 text-brand-accent">{activeCount} <span className="text-xs font-normal text-brand-sand/80">单</span></p>
            </div>
            <div className="w-px h-8 bg-white/20" />
            <div className="text-center">
              <p className="text-xs text-brand-sand/70">累计已送达</p>
              <p className="text-2xl font-serif font-bold mt-1 text-white">{totalCompleted} <span className="text-xs font-normal text-brand-sand/80">次</span></p>
            </div>
          </div>
        </div>
      </div>

      {/* Main navigation Tabs */}
      <main className="max-w-7xl mx-auto px-4 mt-6">
        <div className="flex gap-2 bg-white p-1.5 rounded-2xl border border-brand-border shadow-xs max-w-md mb-6">
          <button
            id="tab-nav-book"
            onClick={() => setActiveTab('book')}
            className={`flex-1 py-3 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'book'
                ? 'bg-brand-green text-white shadow-xs'
                : 'text-brand-charcoal/70 hover:bg-brand-warm-gray'
            }`}
          >
            <CalendarCheck className="w-4 h-4" /> 预约孝心陪伴
          </button>
          <button
            id="tab-nav-elders"
            onClick={() => setActiveTab('elders')}
            className={`flex-1 py-3 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'elders'
                ? 'bg-brand-green text-white shadow-xs'
                : 'text-brand-charcoal/70 hover:bg-brand-warm-gray'
            }`}
          >
            <User className="w-4 h-4" /> 长辈信息档案
          </button>
          <button
            id="tab-nav-orders"
            onClick={() => setActiveTab('orders')}
            className={`flex-1 py-3 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 relative ${
              activeTab === 'orders'
                ? 'bg-brand-green text-white shadow-xs'
                : 'text-brand-charcoal/70 hover:bg-brand-warm-gray'
            }`}
          >
            <ClipboardCheck className="w-4 h-4" /> 孝心订单
            {activeCount > 0 && (
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-brand-accent rounded-full animate-ping" />
            )}
          </button>
        </div>

        {/* Dynamic Tab Panels with smooth transitions */}
        <div className="min-h-[400px]">
          {activeTab === 'book' && (
            <div id="panel-book" className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start text-left">
              <div className="lg:col-span-8">
                <BookingForm
                  elders={elders}
                  selectedElderId={selectedElderId}
                  onBookingSuccess={handleBookingSuccess}
                />
              </div>

              {/* Sidebar Guide */}
              <div className="lg:col-span-4 space-y-6">
                {/* Micro Elder profile picker on the booking page */}
                <div className="bg-white rounded-2xl shadow-xs border border-brand-border p-5">
                  <h3 className="text-xs font-bold text-brand-charcoal uppercase tracking-wider mb-3.5">
                    已建长辈快捷选择
                  </h3>
                  {elders.length > 0 ? (
                    <div className="space-y-2">
                      {elders.map((e) => (
                        <div
                          key={e.id}
                          id={`quick-select-elder-${e.id}`}
                          onClick={() => setSelectedElderId(e.id)}
                          className={`p-3 rounded-xl border text-xs flex items-center justify-between cursor-pointer transition-all ${
                            selectedElderId === e.id
                              ? 'bg-brand-green/5 border-brand-green text-brand-charcoal font-semibold'
                              : 'bg-brand-sand/30 border-brand-border hover:bg-brand-warm-gray text-brand-charcoal/80'
                          }`}
                        >
                          <div className="flex items-center gap-2.5">
                            <span className="w-6 h-6 rounded-full bg-brand-green/10 text-brand-green font-bold flex items-center justify-center text-[10px]">
                              {e.name.substring(0, 1)}
                            </span>
                            <span>{e.name} ({e.relation})</span>
                          </div>
                          <span className="text-[10px] text-brand-charcoal/50">{e.age}岁</span>
                        </div>
                      ))}
                      <button
                        onClick={() => setActiveTab('elders')}
                        className="text-xs font-bold text-brand-green hover:text-brand-green/80 flex items-center gap-1 mt-3 w-full justify-center py-2 bg-brand-green/5 rounded-xl border border-dashed border-brand-green/20"
                      >
                        管理或新增长辈档案 →
                      </button>
                    </div>
                  ) : (
                    <div className="text-center py-6">
                      <p className="text-xs text-brand-charcoal/50 mb-3">暂无已存档案</p>
                      <button
                        onClick={() => setActiveTab('elders')}
                        className="text-xs font-bold text-white bg-brand-green hover:bg-brand-green/90 px-4 py-2 rounded-xl transition-all"
                      >
                        立即去建档
                      </button>
                    </div>
                  )}
                </div>

                {/* FAQ section */}
                <div className="bg-white rounded-2xl shadow-xs border border-brand-border p-5 space-y-4">
                  <h3 className="text-xs font-bold text-brand-charcoal flex items-center gap-1.5 border-b border-brand-border pb-3">
                    <HelpCircle className="w-4 h-4 text-brand-green" />
                    用户预约指南
                  </h3>

                  <div className="space-y-3.5 text-xs">
                    <div>
                      <p className="font-bold text-brand-charcoal">Q：什么是「半小时起步预订」？</p>
                      <p className="text-brand-charcoal/75 leading-relaxed mt-1">
                        考虑长辈精力、也为年轻人提供低门槛孝心通路，「温情寒暄」特提供0.5小时起订，由陪护师上门带去您挑选的低糖甜点或花束，在半小时内完成礼貌聊天与暖心关怀，打消长辈心理孤寂。
                      </p>
                    </div>

                    <div>
                      <p className="font-bold text-brand-charcoal">Q：如何确保上门人员的安全与素质？</p>
                      <p className="text-brand-charcoal/75 leading-relaxed mt-1">
                        「孝了么」所有服务人员均经过三重严格筛选：实名身份公安背景比对、老龄陪护/急救实操认证考核、及沟通耐心度专业测评，均承保百万级家政责任险。
                      </p>
                    </div>

                    <div>
                      <p className="font-bold text-brand-charcoal">Q：怎么查看服务反馈与长辈状况？</p>
                      <p className="text-brand-charcoal/75 leading-relaxed mt-1">
                        每次陪伴结束，陪护师会在1小时内上传一份「探望反馈报告」，记录长辈的精神状况、聊天活动内容，并附带嘱咐和现场合影，供您省心掌握长辈近况。
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'elders' && (
            <div id="panel-elders" className="space-y-6 text-left">
              <ElderProfileManager
                elders={elders}
                onAddElder={handleAddElder}
                onDeleteElder={handleDeleteElder}
                selectedElderId={selectedElderId}
                onSelectElder={setSelectedElderId}
              />
            </div>
          )}

          {activeTab === 'orders' && (
            <div id="panel-orders" className="space-y-6 text-left">
              <OrderTracker
                orders={orders}
                onAdvanceOrderStatus={handleAdvanceOrderStatus}
                onCancelOrder={handleCancelOrder}
              />
            </div>
          )}
        </div>
      </main>

      {/* Footer copyright */}
      <footer className="max-w-7xl mx-auto px-4 mt-16 text-center border-t border-brand-border pt-8 text-xs text-brand-charcoal/50">
        <div className="flex items-center justify-center gap-1 text-brand-charcoal/70 font-bold mb-2">
          <Heart className="w-3.5 h-3.5 text-brand-green fill-brand-green" />
          <span className="font-serif">孝了么 · 陪伴长辈 温暖小家</span>
        </div>
        <p>© 2026 孝了么养老关怀服务有限公司。沪ICP备20261120号</p>
        <p className="mt-1 text-brand-charcoal/40">本平台所有上门陪护师均经过三级实名公安联防背审。陪诊医疗辅助服务不包含开具处方等行医行为。</p>
      </footer>
    </div>
  );
}
